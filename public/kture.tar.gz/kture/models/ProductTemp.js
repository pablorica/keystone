var keystone = require('keystone');
var Types = keystone.Field.Types;

/**
 * ProductTempTemp Model
 * ==========
 */

var ProductTemp = new keystone.List('ProductTemp', {
	map: { name: 'title' },
	autokey: { path: 'slug', from: 'title', unique: true }
});

ProductTemp.add({
	title: { type: String, required: true },
	product_id: { type: String,  index: true},
	createdOn: { type: Types.Date},
	merchant_id: { type: String},
	merchant_name: { type: String},
	description: {
		brief: { type: Types.Html, wysiwyg: true, height: 150 },
		extended: { type: Types.Html, wysiwyg: true, height: 400 }
	},
	brand: { type: String },
	price: { type: Number },
	currency: { type: String },
	URL: { type: String },
	attributeClass_size: { type: String },
	attributeClass_color: { type: String },
	productImage: { type: Types.CloudinaryImage },
	category_primary: { type: String },
	category_secondary: { type: String },
	state: { type: Types.Select, options: 'catalogue, new, updated, deleted', default: 'catalogue' },
	control: { type: String }
});

ProductTemp.schema.virtual('description.full').get(function() {
	return this.description.extended || this.description.brief;
});

ProductTemp.defaultColumns = 'title|20%, merchant_name|20%, brand|20%, category_primary|20%, createdOn|20%';
ProductTemp.register();

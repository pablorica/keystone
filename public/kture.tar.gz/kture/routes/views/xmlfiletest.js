var keystone = require('keystone'),
	async = require('async');

var fs = require('fs'),
    xml2js = require('xml2js');




		

exports = module.exports = function(req, res, done) {
	
	var locals = res.locals;
	//console.log(res);

	var error_message='';
	var error_code=null;
	var all_result=[];

	async.series([

		function(next) {
            
            var parser = new xml2js.Parser();
            
			fs.readFile(__dirname + '/../../public/xml/foo.xml', function(err, data) {
			    parser.parseString(data, function (err, result) {
				    //console.dir(data);
				    console.dir(result);
			        console.log('Done');
				    if(err){
					    error_message=err;
						error_code=1;
					    next();
				    }else {
					    all_result=result;
					    next();
				    }
				});
			});
					
		}

	], function(err) {
			res.json(
			{"result": all_result, "session_id": req.sessionID, "error_code": error_code, "error_message": error_message});
			/*
			res.json(
			{"result": __dirname + '/../../public/xml/foo.xml', "session_id": req.sessionID, "error_code": error_code, "error_message": error_message});
*/

	});
		
	
}
var keystone = require('keystone'),
	async = require('async');
var parseString = require('xml2js').parseString;
		

exports = module.exports = function(req, res, done) {
	
	var locals = res.locals;
	//console.log(res);

	var error_message='';
	var error_code=null;
	var all_result=[];

	async.series([

		function(next) {
            
			var xml = "<root>Hello xml2js!</root>";
			parseString(xml, function (err, result) {
			    console.dir(result);
			    console.log('Done');
			    if(err){
				    error_message=err;
					error_code=1;
				    next();
			    }else {
				    all_result=result;
				    next();
			    }
			});
					
		}

	], function(err) {
		
			res.json(
			{"result": all_result, "session_id": req.sessionID, "error_code": error_code, "error_message": error_message});
		

	});
		
	
}
var keystone = require('keystone'),
	async = require('async'),
	Product = keystone.list('Product');
		

exports = module.exports = function(req, res, done) {
	
	var view = new keystone.View(req, res);
	
	var locals = res.locals;
	//console.log(res);
	
	// Set locals
	locals.section = 'products';
	locals.data = {
		products: []
	};

	var error_message='';
	var error_code=null;
	var all_result=[];
	


	

	async.series([

		function(next) {
            
            /*var q = Product.model.find().sort('name');*/
            var q = keystone.list('Product').paginate({
				page: req.query.page || 1,
				perPage: 10,
				maxPages: 10
			})
			.sort('name');
		
		
			q.exec(function(err, products) {
				
				if (err) {
					console.log(err.message);
					error_message=err.message;
					error_code=2;
					return next();
				} else {
				
					if (products) {
						//all_result=products;
						locals.data.posts = products;
						next();
					} else {
						error_message='No products';
						error_code=3;
						next();
					}
					
				}
				
			});
					
		}

	], function(err) {
			
			// Render the view
			view.render('products');
			/*res.json(
			{"result": all_result, "session_id": req.sessionID, "error_code": error_code, "error_message": error_message});*/
		

	});
		
	
}
var keystone = require('keystone'),
	async = require('async');

var Client = require('ftp');

var fs = require('fs');

var zlib = require('zlib');

var xml2js = require('xml2js');

var Product = keystone.list('Product');


/******** FTP ********
ftp://aftp.linksynergy.com/
Site ID: 3280362
FTP username: Kture
FTP password: Smu9jDW3

35725 Matches Fashion
37410 Saks Fifth Avenue
37544 Avenue 32 UK
37938 Farfetch AU
38014 LuisaViaRoma US
38021 LuisaViaRoma UK
39322 Italist
*********************/


var c = new Client();
  
		

exports = module.exports = function(req, res, done) {
	
	var locals = res.locals;
	//console.log(res);

	var error_message='';
	var error_code=null;
	var all_result=[];
	
	
	var file_to_download='35725_3280362_mp_delta.xml.gz';
	var file_end='35725_3280362_mp_delta.xml';
	var exists_file=0;
	var exists_decompress=0;

	
	var products = [];
	
	var super_products = [];

	async.series([

		
		// First: Exists file?

		/*
		function (next) {
			
			
			fs.access('uploads/'+file_to_download, fs.R_OK | fs.W_OK, function (err) {
			    if (!err) {
			        console.log('Exists file_to_download: '+file_to_download);
					exists_file=1;
					next();
			    } else {
			       console.log('We need to download file.');
			       next();
			    }
			});
					
		},
		*/			
		
		// Second: Download a file
		
		function(next) {
			
			if (exists_file==0) {
			
				c.on('ready', function() {
				    c.get(file_to_download, function(err, stream) {
				      if (err) {
					      error_message=err;
						  error_code=1;
						  next();
				      } else {
					      stream.once('close', function() { 
						      c.end();
						      all_result = 'Nice!';
						      exists_file=1;
						      next();
						  });
				          stream.pipe(fs.createWriteStream('uploads/'+file_to_download));
				      }
				      
				    });
				});
				// connect to localhost:21 as anonymous
				c.connect({
				    host: "aftp.linksynergy.com",
				    port: 21, // defaults to 21
				    user: "Kture", 
				    password: "Smu9jDW3"
				});
			} else {
				console.log('Nothing to download');
				next();
			}
					
		},
		
		/*
		function (next) {
			
			fs.access('uploads/'+file_end, fs.R_OK | fs.W_OK, function (err) {
			    if (!err) {
			        console.log('Exists file_end: '+file_end);
					exists_decompress=1;
					next();
			    } else {
			       console.log('We need to compress file.');
			       next();
			    }
			});
			
		},

		*/		
		
		
		// Fifth: Gzip File
		
		function(next) {
			if (exists_decompress==0) {
				
				
				console.log('Let\'s decompress');
				var inp = fs.createReadStream('uploads/'+file_to_download);
				var out = fs.createWriteStream('uploads/'+file_end);
				
				inp.pipe(zlib.createGunzip()).pipe(out);
				
				out.on('finish', function(err) {
					
					if (err) {
						//console.log('fail!');
						next();
					} else {
						all_result='We got the file';
						//console.log('success');
						exists_decompress=1;
						next();
					}
					
				});
								
			} else {
				next();
			}
			
		},
		
		
		
		function (next) {
			
			if (exists_decompress==1) {
			
			var parser = new xml2js.Parser();
            
				fs.readFile('uploads/'+file_end, function(err, data) {
				    parser.parseString(data, function (err, result) {
					    //console.dir(data);
					    //console.log(JSON.stringify(result," ", 2));
				        //console.log('Done');
					    
					    header = result.merchandiser.header;
					    products = result.merchandiser.product;
					    
					    //console.log(result.merchandiser.product);
					    
					    if(err){
						    error_message=err;
							error_code=1;
						    next();
					    }else {
						    all_result=result;
						    next();
					    }
					});
				});

			} else {
				next();
			}
			
		},
		
		
		function (next) {
			
			if (products.length>0) {
				
				//console.log(JSON.stringify(products," ", 2));
				//console.log('Header '+JSON.stringify(header," ", 2));
				
				var i=0;
				products.forEach(function(product) {
					i++;
	
					//console.log(JSON.stringify(product," ", 2));
					
					var product_name='';
					if (typeof product.$.name != 'undefined' && product.$.name !='') {
						//console.log(product.$.name);
						product_name=product.$.name;
					}
					
					var product_id='';
					if (typeof product.$.product_id != 'undefined' && product.$.product_id !='') {
						//console.log(product.$.product_id);
						product_id=product.$.product_id;
					}
					
					var product_createdon='';
					var product_merchant_id='';
					var product_merchant_name='';
					if (typeof header != 'undefined' && header.length>0) {
						if (typeof header[0].createdOn != 'undefined' && header[0].createdOn.length>0) {
							if (typeof header[0].createdOn[0] != 'undefined' && header[0].createdOn[0] !='') {
								//console.log(header[0].createdOn[0]);
								product_createdon=header[0].createdOn[0];
							}
						}
						if (typeof header[0].merchantId != 'undefined' && header[0].merchantId.length>0) {
							if (typeof header[0].merchantId[0] != 'undefined' && header[0].merchantId[0] !='') {
								//console.log(header[0].merchantId[0]);
								product_merchant_id=header[0].merchantId[0];
							}
						}
						if (typeof header[0].merchantName != 'undefined' && header[0].merchantName.length>0) {
							if (typeof header[0].merchantName[0] != 'undefined' && header[0].merchantName[0] !='') {
								//console.log(header[0].merchantName[0]);
								product_merchant_name=header[0].merchantName[0];
							}
						}
					}

					
					var product_url='';
					var product_url_image='';
					if (typeof product.URL != 'undefined' && product.URL.length>0) {
						if (typeof product.URL[0].product != 'undefined' && product.URL[0].product.length>0) {
							if (typeof product.URL[0].product[0] != 'undefined' && product.URL[0].product[0] !='') {
								//console.log(product.URL[0].product[0]);
								product_url=product.URL[0].product[0];
							}
						}
						if (typeof product.URL[0].productImage != 'undefined'  && product.URL[0].productImage.length>0) {
							if (typeof product.URL[0].productImage[0] != 'undefined' && product.URL[0].productImage[0] !='') {
								//console.log(product.URL[0].productImage[0]);
								product_url_image=product.URL[0].productImage[0];
							}
						}
					}
					
					var product_color='';
					var product_size='';
					if (typeof product.attributeClass != 'undefined' && product.attributeClass.length>0) {
						if (typeof product.attributeClass[0].Color != 'undefined' && product.attributeClass[0].Color.length>0) {
							if (typeof product.attributeClass[0].Color[0] != 'undefined' && product.attributeClass[0].Color[0] !='') {
								//console.log(product.attributeClass[0].Color[0]);
								product_color=product.attributeClass[0].Color[0];
							}
						}
						if (typeof product.attributeClass[0].Size != 'undefined' && product.attributeClass[0].Size.length>0) {
							if (typeof product.attributeClass[0].Size[0] != 'undefined' && product.attributeClass[0].Size[0] !='') {
								//console.log(product.attributeClass[0].Size[0]);
								product_size=product.attributeClass[0].Size[0];
							}
						}
					}
	
					var product_brand='';
					if (typeof product.brand != 'undefined' && product.brand.length>0) {
						if (typeof product.brand[0] != 'undefined' && product.brand[0] !='') {
							//console.log(product.brand[0]);
							product_brand=product.brand[0];
						}
					}
					
					var product_category_primary='';
					var product_category_secondary='';
					if (typeof product.category != 'undefined' && product.category.length>0) {
						if (typeof product.category[0].primary != 'undefined' && product.category[0].primary.length>0) {
							if (typeof product.category[0].primary[0] != 'undefined' && product.category[0].primary[0] !='') {
								//console.log(product.category[0].primary[0]);
								product_category_primary=product.category[0].primary[0];
							}
						}
						if (typeof product.category[0].secondary != 'undefined' && product.category[0].secondary.length>0) {
							if (typeof product.category[0].secondary[0] != 'undefined' && product.category[0].secondary[0] !='') {
								//console.log(product.category[0].secondary[0]);
								product_category_secondary=product.category[0].secondary[0];
							}
						}
					}
					
					var product_description_short='';
					var product_description_long='';
					if (typeof product.description != 'undefined' && product.description.length>0) {
						if (typeof product.description[0].short != 'undefined' && product.description[0].short.length>0) {
							if (typeof product.description[0].short[0] != 'undefined' && product.description[0].short[0] !='') {
								//console.log(product.description[0].short[0]);
								product_description_short=product.description[0].short[0];
							}
						}
						if (typeof product.description[0].long != 'undefined' && product.description[0].long.length>0) {
							if (typeof product.description[0].long[0] != 'undefined' && product.description[0].long[0] !='') {
								//console.log(product.description[0].long[0]);
								product_description_long=product.description[0].long[0];
							}
						}
					}
					
					
					var product_price='';
					var product_currency='';
					if (typeof product.price != 'undefined' && product.price.length>0) {
						if (typeof product.price[0].sale != 'undefined' && product.price[0].sale.length>0) {
							if (typeof product.price[0].sale[0] != 'undefined' && product.price[0].sale[0] !='') {
								//console.log(product.price[0].sale[0]);
								product_price=product.price[0].sale[0];
							}
						}
						if (typeof product.price.$ != 'undefined' && product.price.$.length>0) {
							if (typeof product.price.$.currency != 'undefined' && product.price.$.currency !='') {
								//console.log(product.price.$.currency);
								product_currency=product.price.$.currency;
							}
						}
					}

					
				
					var product_tmp={
						"title" : product_name,
						"product_id" : product_id,
						"createdOn" : product_createdon,
						"merchant_id" : product_merchant_id,
					    "merchant_name" : product_merchant_name,
						"URL" : product_url,
						"attributeClass_color" : product_color,
						"attributeClass_size" : product_size,
						"brand" : product_brand,
						"price": product_price,
						"currency": product_currency,
						"category_primary" : product_category_primary,
						"category_secondary" : product_category_secondary,
						"description" : {
							"brief" : product_description_short,
							"extended" : product_description_long,
						},
						"productImage" : {
							"public_id" : "ejdvw9etraj3wjhenqj5",
							"version" : 1453313138,
							"signature" : "1126e03eba9529f2b6193b2c48dfbedcd3c61c7a",
							"width" : 1000,
							"height" : 1300,
							"format" : "jpg",
							"resource_type" : "image",
							"url" : product_url_image,
							"secure_url" : product_url_image
						}
					};
					
					//console.log(JSON.stringify(product_tmp," ", 2));
					
					super_products.push(product_tmp);
					
					if (i===products.length) {
						all_result=super_products;		
						return next();
					}
					
				});

				
				
			} else {
				
				console.log('No products');
				next();
				
			}
			
		},
		
		function (next) {
			
				if (super_products.length>0) {
					
					console.log('Super JSON is ready');
					
					keystone.createItems({
				        ProductTemp: super_products
				      },function(err, stats) {
				        if (err) {
							    error_message='Something wrong has happened when updating database';
							    error_code=5;
							    console.log(err);
							    return next();
						    } else {
							    //console.log(JSON.stringify(stats," ", 2));
							    products_saved=stats;
							    console.log('Database has been updated');
                                return next();
						    }

				      });
					
					

					
				} else {
					
					console.log('Super JSON is not ready');
					next();
					
				}
			
				/*
					
					
				*/
			
		},
		
		function (next) {
				
				/*
				console.log("the type of products_saved is "+typeof products_saved+" and the values is ");
				console.log(JSON.stringify(products_saved," ", 2));
				console.log("the length of products_saved is "+Object.keys(products_saved).length);
				*/
				
				if (Object.keys(products_saved).length>0) {
					
					console.log('We have temporary collection');
					
					var j=0;
					var k=0;
					keystone.list('ProductTemp').model.find().exec(function(err, productemps) {
						if (err) {
						    error_message='Something wrong has happened reading ProductTemp';
						    error_code=6;
						    console.log(err);
						    return next();
					    } else {
						    productemps.forEach(function(productemp) {
							    //console.log("The ProductTemp ID is "+productemp._id);
							    //console.log("The ProductTemp is "+productemp.slug);
							    //console.log(JSON.stringify(productemp," ", 2));
							    k++;
								//console.log("k "+k);
								
								  
								var q = keystone.list('Product').model.findOne({
									//_id: '56abb83902b47505695e22d5'
									slug:productemp.slug
								});
								
								q.exec(function(err, product) {
									if (err) {
									    error_message='Something wrong has happened reading Product';
									    error_code=7;
									    console.log(err);
									    return next();
								    }else {
									    j++;
									    console.log("j "+j);
									    console.log("The Product is "+product.slug);
										//console.log(JSON.stringify(product," ", 2));
									    if(product === productemp){
							                console.log("The Product "+product.slug+" is equal");
							                 
							            }
							            else {
								            console.log("The Product "+product.slug+" is different");
								            
								        }
								    }
								});
							});

						    
						    /*
if (product_finded) {
   
							   products_temp.state = 'updated';
							   callback();
							   
							   } else {
							   
							   products_temp.state = 'new';
							   callback();
							   
							   }
							}
*/
						    return next();
						    
					    }
						
    				});

		
					/*keystone.list('ProductTemp').model.find().forEach(function(obj1){
						console.log("the lproduct is ");
						console.log(JSON.stringify(obj1," ", 2));
				        
keystone.list('Product').model.find().forEach(function(obj2){
				            if(equals(ob1, obj2)){
				                console.log("obj1 = obj2 "+i);
				            }
				        });

				    });*/
					
					/*
					http://stackoverflow.com/questions/9240636/how-to-compare-2-mongodb-collections
					db.eval(compareCollections);
					With db.eval you ensure that code will be executed on the database server side, without fetching collections to the client.
					*/

					
				} else {
					
					console.log('ISSUE: We do not have temporary collection');
					next();
					
				}
			
		}
		
		
	], function(err) {
		
			res.json(
			{"result": all_result, "session_id": req.sessionID, "error_code": error_code, "error_message": error_message});
		

	});
		
	
}
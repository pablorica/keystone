var keystone = require('keystone'),
	async = require('async');

var Client = require('ftp');

/******** FTP ********
ftp://aftp.linksynergy.com/
Site ID: 3280362
FTP username: Kture
FTP password: Smu9jDW3



35725 Matches Fashion
37410 Saks Fifth Avenue
37544 Avenue 32 UK
37938 Farfetch AU
38014 LuisaViaRoma US
38021 LuisaViaRoma UK
39322 Italist
*********************/

  var c = new Client();
  
		

exports = module.exports = function(req, res, done) {
	
	var locals = res.locals;
	//console.log(res);

	var error_message='';
	var error_code=null;
	var all_result=[];

	async.series([

		function(next) {
			
			c.on('ready', function() {
			    c.list(function(err, list) {
			      if(err){
				    error_message=err;
					error_code=1;
					//throw err;
				    next();
			      }else {
				    all_result=list;
				    console.dir(list);
					//c.end();
				    next();
			      }
			    });
			});
			// connect to localhost:21 as anonymous
			c.connect({
			    host: "aftp.linksynergy.com",
			    port: 21, // defaults to 21
			    user: "Kture", 
			    password: "Smu9jDW3"
			});
					
		}

	], function(err) {
		
			res.json(
			{"result": all_result, "session_id": req.sessionID, "error_code": error_code, "error_message": error_message});
		

	});
		
	
}
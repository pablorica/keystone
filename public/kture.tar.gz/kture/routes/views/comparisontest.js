var keystone = require('keystone'),
	async = require('async');

var Client = require('ftp');

var fs = require('fs');

var zlib = require('zlib');

var xml2js = require('xml2js');

var Product = keystone.list('Product');


/******** FTP ********
ftp://aftp.linksynergy.com/
Site ID: 3280362
FTP username: Kture
FTP password: Smu9jDW3

35725 Matches Fashion
37410 Saks Fifth Avenue
37544 Avenue 32 UK
37938 Farfetch AU
38014 LuisaViaRoma US
38021 LuisaViaRoma UK
39322 Italist
*********************/


var c = new Client();


exports = module.exports = function(req, res, done) {
	
	var locals = res.locals;
	//console.log(res);

	var error_message='';
	var error_code=null;
	var all_result=[];
	
	
	var file_to_download='35725_3280362_mp_delta.xml.gz';
	var file_end='35725_3280362_mp_delta.xml';
	var exists_file=0;
	var exists_decompress=0;

	
	var products = [];
	
	var super_products = [];
	
	var products_saved = 0;
	
	var products_inserted = 0;
	
	var products_temp = [];
	
	var products_final = [];
	
	var control_id = Math.floor(new Date());

	async.series([

		
		// First: Exists file?

		/*
		function (next) {
			
			
			fs.access('uploads/'+file_to_download, fs.R_OK | fs.W_OK, function (err) {
			    if (!err) {
			        console.log('Exists file_to_download: '+file_to_download);
					exists_file=1;
					next();
			    } else {
			       console.log('We need to download file.');
			       next();
			    }
			});
					
		},
		*/			
		
		// Second: Download a file
		
		function(next) {
			
			if (exists_file==0) {
			
				c.on('ready', function() {
				    c.get(file_to_download, function(err, stream) {
				      if (err) {
					      error_message=err;
						  error_code=1;
						  next();
				      } else {
					      stream.once('close', function() { 
						      c.end();
						      all_result = 'Nice!';
						      exists_file=1;
						      next();
						  });
				          stream.pipe(fs.createWriteStream('uploads/'+file_to_download));
				      }
				      
				    });
				});
				// connect to localhost:21 as anonymous
				c.connect({
				    host: "aftp.linksynergy.com",
				    port: 21, // defaults to 21
				    user: "Kture", 
				    password: "Smu9jDW3"
				});
			} else {
				console.log('Nothing to download');
				next();
			}
					
		},
		
		/*
		function (next) {
			
			fs.access('uploads/'+file_end, fs.R_OK | fs.W_OK, function (err) {
			    if (!err) {
			        console.log('Exists file_end: '+file_end);
					exists_decompress=1;
					next();
			    } else {
			       console.log('We need to compress file.');
			       next();
			    }
			});
			
		},

		*/		
		
		
		// Fifth: Gzip File
		
		function(next) {
			if (exists_decompress==0) {
				
				
				console.log('Let\'s decompress');
				var inp = fs.createReadStream('uploads/'+file_to_download);
				var out = fs.createWriteStream('uploads/'+file_end);
				
				inp.pipe(zlib.createGunzip()).pipe(out);
				
				out.on('finish', function(err) {
					
					if (err) {
						console.log('fail!');
						next();
					} else {
						all_result='We got the file';
						console.log('success');
						exists_decompress=1;
						next();
					}
					
				});
								
			} else {
				next();
			}
			
		},
		
		
		
		function (next) {
			
			if (exists_decompress==1) {
			
			var parser = new xml2js.Parser();
            
				fs.readFile('uploads/'+file_end, function(err, data) {
				    parser.parseString(data, function (err, result) {
					    //console.dir(data);
					    //console.log(JSON.stringify(result," ", 2));
				        console.log('Done');
					    
					    header = result.merchandiser.header;
					    products = result.merchandiser.product;
					    
					    //console.log(result.merchandiser.product);
					    
					    if(err){
						    error_message=err;
							error_code=1;
						    next();
					    }else {
						    all_result=result;
						    next();
					    }
					});
				});

			} else {
				next();
			}
			
		},
		
		
		function (next) {
			
			if (products.length>0) {
				
				//console.log(JSON.stringify(products," ", 2));
				//console.log('Header '+JSON.stringify(header," ", 2));
				
				var i=0;
				products.forEach(function(product) {
					i++;
	
					//console.log(JSON.stringify(product," ", 2));
					
					var product_name='';
					if (typeof product.$.name != 'undefined' && product.$.name !='') {
						console.log(product.$.name);
						product_name=product.$.name;
					}
					
					var product_id='';
					if (typeof product.$.product_id != 'undefined' && product.$.product_id !='') {
						console.log(product.$.product_id);
						product_id=product.$.product_id;
					}
					
					var product_createdon='';
					var product_merchant_id='';
					var product_merchant_name='';
					if (typeof header != 'undefined' && header.length>0) {
						if (typeof header[0].createdOn != 'undefined' && header[0].createdOn.length>0) {
							if (typeof header[0].createdOn[0] != 'undefined' && header[0].createdOn[0] !='') {
								console.log(header[0].createdOn[0]);
								product_createdon=header[0].createdOn[0];
							}
						}
						if (typeof header[0].merchantId != 'undefined' && header[0].merchantId.length>0) {
							if (typeof header[0].merchantId[0] != 'undefined' && header[0].merchantId[0] !='') {
								console.log(header[0].merchantId[0]);
								product_merchant_id=header[0].merchantId[0];
							}
						}
						if (typeof header[0].merchantName != 'undefined' && header[0].merchantName.length>0) {
							if (typeof header[0].merchantName[0] != 'undefined' && header[0].merchantName[0] !='') {
								console.log(header[0].merchantName[0]);
								product_merchant_name=header[0].merchantName[0];
							}
						}
					}

					
					var product_url='';
					var product_url_image='';
					if (typeof product.URL != 'undefined' && product.URL.length>0) {
						if (typeof product.URL[0].product != 'undefined' && product.URL[0].product.length>0) {
							if (typeof product.URL[0].product[0] != 'undefined' && product.URL[0].product[0] !='') {
								console.log(product.URL[0].product[0]);
								product_url=product.URL[0].product[0];
							}
						}
						if (typeof product.URL[0].productImage != 'undefined'  && product.URL[0].productImage.length>0) {
							if (typeof product.URL[0].productImage[0] != 'undefined' && product.URL[0].productImage[0] !='') {
								console.log(product.URL[0].productImage[0]);
								product_url_image=product.URL[0].productImage[0];
							}
						}
					}
					
					var product_color='';
					var product_size='';
					if (typeof product.attributeClass != 'undefined' && product.attributeClass.length>0) {
						if (typeof product.attributeClass[0].Color != 'undefined' && product.attributeClass[0].Color.length>0) {
							if (typeof product.attributeClass[0].Color[0] != 'undefined' && product.attributeClass[0].Color[0] !='') {
								console.log(product.attributeClass[0].Color[0]);
								product_color=product.attributeClass[0].Color[0];
							}
						}
						if (typeof product.attributeClass[0].Size != 'undefined' && product.attributeClass[0].Size.length>0) {
							if (typeof product.attributeClass[0].Size[0] != 'undefined' && product.attributeClass[0].Size[0] !='') {
								console.log(product.attributeClass[0].Size[0]);
								product_size=product.attributeClass[0].Size[0];
							}
						}
					}
	
					var product_brand='';
					if (typeof product.brand != 'undefined' && product.brand.length>0) {
						if (typeof product.brand[0] != 'undefined' && product.brand[0] !='') {
							console.log(product.brand[0]);
							product_brand=product.brand[0];
						}
					}
					
					var product_category_primary='';
					var product_category_secondary='';
					if (typeof product.category != 'undefined' && product.category.length>0) {
						if (typeof product.category[0].primary != 'undefined' && product.category[0].primary.length>0) {
							if (typeof product.category[0].primary[0] != 'undefined' && product.category[0].primary[0] !='') {
								console.log(product.category[0].primary[0]);
								product_category_primary=product.category[0].primary[0];
							}
						}
						if (typeof product.category[0].secondary != 'undefined' && product.category[0].secondary.length>0) {
							if (typeof product.category[0].secondary[0] != 'undefined' && product.category[0].secondary[0] !='') {
								console.log(product.category[0].secondary[0]);
								product_category_secondary=product.category[0].secondary[0];
							}
						}
					}
					
					var product_description_short='';
					var product_description_long='';
					if (typeof product.description != 'undefined' && product.description.length>0) {
						if (typeof product.description[0].short != 'undefined' && product.description[0].short.length>0) {
							if (typeof product.description[0].short[0] != 'undefined' && product.description[0].short[0] !='') {
								console.log(product.description[0].short[0]);
								product_description_short=product.description[0].short[0];
							}
						}
						if (typeof product.description[0].long != 'undefined' && product.description[0].long.length>0) {
							if (typeof product.description[0].long[0] != 'undefined' && product.description[0].long[0] !='') {
								console.log(product.description[0].long[0]);
								product_description_long=product.description[0].long[0];
							}
						}
					}
					
					
					var product_price='';
					var product_currency='';
					if (typeof product.price != 'undefined' && product.price.length>0) {
						if (typeof product.price[0].sale != 'undefined' && product.price[0].sale.length>0) {
							if (typeof product.price[0].sale[0] != 'undefined' && product.price[0].sale[0] !='') {
								console.log(product.price[0].sale[0]);
								product_price=product.price[0].sale[0];
							}
						}
						if (typeof product.price.$ != 'undefined' && product.price.$.length>0) {
							if (typeof product.price.$.currency != 'undefined' && product.price.$.currency !='') {
								console.log(product.price.$.currency);
								product_currency=product.price.$.currency;
							}
						}
					}

					
				
					var product_tmp={
						"control": control_id,
						"title" : product_name,
						"product_id" : product_id,
						"createdOn" : product_createdon,
						"merchant_id" : product_merchant_id,
					    "merchant_name" : product_merchant_name,
						"URL" : product_url,
						"attributeClass_color" : product_color,
						"attributeClass_size" : product_size,
						"brand" : product_brand,
						"price": product_price,
						"currency": product_currency,
						"category_primary" : product_category_primary,
						"category_secondary" : product_category_secondary,
						"description" : {
							"brief" : product_description_short,
							"extended" : product_description_long,
						},
						"productImage" : {
							"public_id" : "ejdvw9etraj3wjhenqj5",
							"version" : 1453313138,
							"signature" : "1126e03eba9529f2b6193b2c48dfbedcd3c61c7a",
							"width" : 1000,
							"height" : 1300,
							"format" : "jpg",
							"resource_type" : "image",
							"url" : product_url_image,
							"secure_url" : product_url_image
						}
					};
					
					//console.log(JSON.stringify(product_tmp," ", 2));
					
					super_products.push(product_tmp);
					
					if (i===products.length) {
						all_result=super_products;		
						return next();
					}
					
				});

				
				
			} else {
				
				console.log('No products');
				next();
				
			}
			
		},
		
		function (next) {
			
				if (super_products.length>0) {
					
					console.log('Super JSON is ready');
					
					keystone.createItems({
				        ProductTemp: super_products
				      },function(err, stats) {
				        if (err) {
							    error_message='Something wrong has happened when updating database';
							    error_code=5;
							    console.log(err);
							    return next();
						    } else {
							    //console.log(JSON.stringify(stats," ", 2));
							    products_saved=stats.ProductTemp.created;
							    console.log('We have these products ------- : '+products_saved);
                                return next();
						    }

				      });

					
				} else {
					
					console.log('Super JSON is not ready');
					next();
					
				}
			
				/*
					
					
				*/
			
		},
		
		
		/* We get all Temp products */
		
		
		function (next) {
			
			if (products_saved>0) {
				keystone.list('ProductTemp').model.find({ control: control_id }, { control: 0 }).exec(function(err, products_result) {
				//keystone.list('ProductTemp').model.find({ control: control_id }).exec(function(err, products_result) {
					if (err) {
					    error_message='Something wrong has happened reading ProductTemp';
					    error_code=6;
					    console.log(err);
					    return next();
				    } else {
					    
						
						products_temp=products_result;
						
	                    return next();
				    }
					
				});
    		} else {
					
				console.log('ISSUE: We do not have products saved');
				next();
				
			}	
	
		},

		
		function (next) {
				

				if (products_temp.length>0) {
					
					
					async.eachSeries(products_temp, function(product_temp, callingback) {
					
						//console.log(product_temp._id);
						
						product_state = 'catalogue';
	
						keystone.list('Product').model.findOne({ product_id: product_temp.product_id }, { control: 0 }).exec(function(err, pro_result) {
							if (err) {
							    error_message='Something wrong has happened reading Product';
							    error_code=7;
							    console.log(err);
							    callingback();
						    } else {
								product_ori=pro_result;
								//console.log("The Product original ");
								//console.log(JSON.stringify(product_ori));
								//console.log("The Product new ");
								//console.log(JSON.stringify(product_temp));
								
								if( (product_ori.title=== product_temp.title)  &&  (product_ori.description.brief === product_temp.description.brief) &&  (product_ori.description.extended === product_temp.description.extended) &&  (product_ori.brand=== product_temp.brand )  &&  (product_ori.price === product_temp.price ) &&  (product_ori.currency === product_temp.currency ) &&  (product_ori.URL === product_temp.URL) &&  (product_ori.attributeClass_size === product_temp.attributeClass_size) &&  (product_ori.attributeClass_color === product_temp.attributeClass_color) &&  (product_ori.category_primary === product_temp.category_primary)  &&  (product_ori.category_secondary === product_temp.category_secondary) ){
					                //console.log("The Product "+product_ori.slug+" is equal");
					                product_state = 'catalogue';
					                
					            }
					            else {
						            //console.log("The Product "+product_ori.slug+" is different");
						            product_state = 'updated';
									
						            
						        }
			                    
						    }
							
						});
						
						if (product_state!='') {
		
							Product.model.findOneAndRemove({ product_id: product_temp.product_id }).exec(function(err, product_finded) {
								if (err) {
								    error_message='Something wrong has happened removing';
								    error_code=6;
								    console.log(err);
								    callingback();
							    } else {
		
								    //console.log(product_finded);
								    
								    if (product_finded) {
									    
									    product_temp.state = product_state;
									    
									    products_final.push(product_temp);
									    
									    
									    callingback();
									    
								    } else {
									    
									    product_temp.state = 'new';
									    products_final.push(product_temp);
									    
									   // console.log(product_finded+' ----new');
									    
									    callingback();
									    
								    }
								    
							    }
							
	    					});
					  	}

					
					}, function(err){
					    // if any of the product processing produced an error, err would equal that error
					    if( err ) {
					      // One of the iterations produced an error.
					      // All processing will now stop.
					      console.log(err);
					      console.log('A product failed to process');
					      next();
					    } else {
					      console.log('All products have been processed successfully');
					      next();
					    }
					});
					
				} else {
					
					console.log('ISSUE: We do not have temporary collection');
					next();
					
				}
			
		},
		
		function (next) {
				
			    console.log('here we go: '+products_final.length);

				//console.log(products_final);

				if (products_final.length>0) {
					
					
					console.log('this is the end');
					
					
					async.eachSeries(products_final, function(product_final, callback) {
					
						
					
						var newProduct = new Product.model(product_final);
	    				newProduct.save(function(err) {
		    				//console.log(product_final.product_id);
		    				//console.log(product_final.state);
		    				if (err) {
							    error_message='Something amazing has happend';
							    error_code=5;
							    console.log(err);
							    callback();
						    } else {
								//console.log(product_final.title);
                                callback();
						    }
						});

					
					}, function(err){
					    // if any of the product processing produced an error, err would equal that error
					    if( err ) {
					      // One of the iterations produced an error.
					      // All processing will now stop.
					      console.log(err);
					      console.log('A product final failed to process');
					      next();
					    } else {
					      console.log('All products final have been processed successfully');
					      next();
					    }
					});
					
					/*
					keystone.createItems({
				        Product: products_final
				      },function(err, stats) {
				        if (err) {
							    error_message='Something wrong has happened when updating database';
							    error_code=5;
							    console.log(err);
							    return next();
						    } else {
							    console.log(JSON.stringify(stats," ", 2));
							    //products_saved=stats.ProductTemp.created;
							    //console.log('We have these products ------- : '+products_saved);
                                return next();
						    }

				      });
				      */

					
				} else {
					
					console.log('ISSUE: We do not have temporary collection');
					next();
					
				}
			
		}
		
		
	], function(err) {
		
			res.json(
			{"result": all_result, "session_id": req.sessionID, "error_code": error_code, "error_message": error_message});
		

	});
		
	
}
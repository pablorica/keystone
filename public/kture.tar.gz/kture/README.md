Keystone Starter
================

[![Deploy](https://www.herokucdn.com/deploy/button.png)](https://heroku.com/deploy?template=https://github.com/JedWatson/keystone-starter)

This is a starter project for [KeystoneJS](http://keystonejs.com) set up with clean templates and sensible defaults that can be immediately deployed to [Heroku](https://www.heroku.com) (or anywhere else).

It is based on the [KeystoneJS Yeoman Generator](https://github.com/keystonejs/generator-keystone) which you should look at if you want more customisation options.


...
...

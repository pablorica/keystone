# redsys_direct_pay

This is a plugin to pay with Redsys payment system.

git clone https://github.com/monchopena/redsys_direct_pay.git


